package com.example.adrian_jadid_desarrollo_de_apps_act_3;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
public class OtraPaginaActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otra_pagina);

        // Obtén referencias a los elementos de la interfaz de usuario
        TextView welcomeMessage = findViewById(R.id.welcomeMessage);
        EditText nombreEditText = findViewById(R.id.nombre);
        EditText edadEditText = findViewById(R.id.edad);
        EditText ciudadEditText = findViewById(R.id.ciudad);
        Button guardarButton = findViewById(R.id.guardarButton);

        // Configura un clic en el botón "Guardar"
        guardarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtén los valores ingresados en los campos
                String nombre = nombreEditText.getText().toString();
                String edad = edadEditText.getText().toString();
                String ciudad = ciudadEditText.getText().toString();

                // Puedes hacer lo que necesites con estos valores, por ejemplo, guardarlos en una base de datos.

                // Cierra la actividad actual (vuelve a la actividad anterior)
                finish();
            }
        });
    }

}
